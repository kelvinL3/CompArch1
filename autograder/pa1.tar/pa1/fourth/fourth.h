//globals
int size;


//fun-ctions
int ** multiply(int **baseArray, int **array);

int dot(int **baseArray, int **array, int rowNumber, int colNumber);

void printMatrix(int **baseArray);